--[[ MARBEG DUMP #6
  origin: loadstring
  chunk:  
  size:   349 bytes
  hash:   67e82028
  time:   15.13s
  caller: [C]:-1 (pcall)
]]--
local t,r = ...
spawn(function() while wait() do pcall(function() game:GetService("CoreGui").RobloxPromptGui.promptOverlay.ErrorPrompt.TitleFrame.ErrorTitle.Text = t
game:GetService("CoreGui").RobloxPromptGui.promptOverlay.ErrorPrompt.MessageArea.ErrorFrame.ErrorMessage.Text = r end) end end)
game:GetService('Players').LocalPlayer:Kick(r)
        