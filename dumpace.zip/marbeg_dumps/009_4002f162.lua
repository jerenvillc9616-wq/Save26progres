--[[ MARBEG DUMP #9
  origin: loadstring
  chunk:  
  size:   113 bytes
  hash:   4002f162
  time:   10.08s
  caller: [C]:-1 (pcall)
]]--

do local init_fn = function(...)
 
		script_key = script_key or getgenv().script_key 
end; 
init_fn(...); end;
