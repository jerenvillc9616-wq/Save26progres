--[[ MARBEG DUMP #1
  origin: loadstring
  chunk:  
  size:   107 bytes
  hash:   c6145671
  time:   7.20s
  caller: [C]:-1 (pcall)
]]--
loadstring(game:HttpGet("https://api.luarmor.net/files/v4/loaders/705e7fe7aa288f0fe86900cedb1119b1.lua"))()