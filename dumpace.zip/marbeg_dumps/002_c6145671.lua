--[[ MARBEG v4 DUMP #2
  origin: http:HttpGet
  chunk:  @https://rawscripts.net/raw/Attack-on-Titan-Revolution-Tekkit
  size:   107
  hash:   c6145671
  time:   51.67s
]]--
loadstring(game:HttpGet("https://api.luarmor.net/files/v4/loaders/705e7fe7aa288f0fe86900cedb1119b1.lua"))()