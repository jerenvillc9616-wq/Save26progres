--[[ MARBEG DUMP #8
  origin: loadstring
  chunk:  
  size:   1413 bytes
  hash:   63009998
  time:   9.06s
  caller: [C]:-1 (pcall)
]]--
-- Do not save this file
-- Always use the loadstring 
  _bsdata0={4070682903,"3L1-.4A-3.AB3B0DE304LC-C55_D3R.022L4.-.DL0C3BDR-B4-1._0_2RL143L4._5RC5_3EL__4D-R-3LER15E_RER1CA_DRA3ACC0D1.1B4D5.-CL34L_LAL44_4EC33B",28575232,"\178\77\37\91\27\114\32\24\159\232\99\244\201\199\168\151\107\0\71\67\190\154\205\19\64\157\115\99\170",19740200,3209802455,1776575789,2851531,2645682,47543616,"8e42c93cb930e9f121e86132fdf303d7466e8cfbff29273e9f62b28bed2b88b04ba3b0b41fc62d032ad4f451578a88749edc038237a0142c7a098e8bb2e07f8308a248a40356a951c1ae7c8fc6ec0d1efa3ba71a243711ed06c6876f14e22884a686b0b053ad18a53650a7ed4de44f73c91c4136cfb9ce0372d7cd8383f9f965734ef4b09a156d25ee432def2fe2b804bfe3b0283b57f3b7b1d4bb780406498666ab1ef78aa0d77cd2302333dc76294b7fd064918437aefc428908e1a964bf1ea4c5a5a9ec34c790","\220\159\221\176\13\80\86\178\29\245\90\164\167\95\51\53\21\48\93\183\105\227\13\163"};
local f,b,a="static_content_130525","74c74f95fd0-marbeg";pcall(function()a=readfile(f.."/init-"..b..".lua")end) if a and #a>2000 then a=loadstring(a) else a=nil; end;
if a then return a() else pcall(makefolder,f) a=game:HttpGet("https://cdn.luarmor.net/v4_init_marbeg.lua"..(_ca920af6193 or "")) writefile(f.."/init-"..b..".lua", a); 
pcall(function() for i,v in pairs(listfiles('./'..f)) do local m=v:match('(init[%w%-]*).lua$') if m and m~=('init-'..b) then pcall(delfile, f..'/'..m..'.lua') end end; end); return loadstring(a)() end
  