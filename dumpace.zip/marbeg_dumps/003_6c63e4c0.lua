--[[ MARBEG v4 DUMP #3
  origin: http:HttpGet
  chunk:  @https://api.luarmor.net/files/v4/loaders/705e7fe7aa288f0fe86
  size:   1416
  hash:   6c63e4c0
  time:   52.27s
]]--
-- Do not save this file
-- Always use the loadstring 
  _bsdata0={4037114253,"A5ER4DED04A.4B_.R51E_R.4DL43B_-R3_RR_-0CRC.3BDE__.C454_2-2D1AA_10E50C31.00C0CD04-LD2152RCR5-1CB2L344_.B-2A2R51RB.2-12111D1DEDR0C40A004",22985020,"\178\77\37\91\27\114\32\24\159\232\99\244\201\199\168\151\107\0\71\67\190\154\205\19\64\157\115\99\170",5749400,4147365246,1776677014,2851531,2645682,41388016,"cf6cf43d589c2cddbefa503b7399853fa8b9dd586db04150ef4914fa03de73514d134f185cd55b96eb2122cd8ba25dfaac897c9a9930d0f5e396ecca9e6a71d52a6239c58918d1a2338a3f7371c02491a7a515c1b154736e3197a430849ed93485e77217840e3225657531a532bc56ab94692bba190af00c6fd629f0841822ed2a3973169e174a38e945376c4910068d2451397d6e1172e24830a5d6ed6de1021cb4a1acbdd841805db0908ce9d78ab5de3b3b4ccc87c962e3a079248f2d9dd43efdf51bbd39d410bc","\220\159\221\176\13\80\86\178\29\245\90\164\167\95\51\53\21\48\93\183\105\227\13\163"};
local f,b,a="static_content_130525","74c74f95fd0-marbeg";pcall(function()a=readfile(f.."/init-"..b..".lua")end) if a and #a>2000 then a=loadstring(a) else a=nil; end;
if a then return a() else pcall(makefolder,f) a=game:HttpGet("https://cdn.luarmor.net/v4_init_marbeg.lua"..(_ca920af6193 or "")) writefile(f.."/init-"..b..".lua", a); 
pcall(function() for i,v in pairs(listfiles('./'..f)) do local m=v:match('(init[%w%-]*).lua$') if m and m~=('init-'..b) then pcall(delfile, f..'/'..m..'.lua') end end; end); return loadstring(a)() end
  