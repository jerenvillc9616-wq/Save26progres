--[[ MARBEG DUMP #2
  origin: loadstring
  chunk:  
  size:   1417 bytes
  hash:   d1236cd8
  time:   8.01s
  caller: [C]:-1 (pcall)
]]--
-- Do not save this file
-- Always use the loadstring 
  _bsdata0={692035060,"3--_LB-0RL32LL4L0A3B4..4B252D5-R41RRDD0C24.3C1E_2RC4C-_23RD1.C_13050-E1.4LE3D3312431E00E1E.-RE2DB_5C-AL-ER00AA.1CCLC13R43.33.-15C1C503R.",9918412,"\178\77\37\91\27\114\32\24\159\232\99\244\201\199\168\151\107\0\71\67\190\154\205\19\64\157\115\99\170",31056550,2816693461,1776676215,2851531,2645682,14359336,"a617ddf278ca6ed68adcb9b80c69bb4849e4ce1dd0feaad10bd9645980425acfbc5676fdc34ba92d2c87f924aa8305e57524c4e9e848436bf53d44ae3d3876881b563ca3d57d178df632197e893553827de049f34549a8d2b587c4d6e7845f9371aac2cbf8b7ef656f5d072fbe457b3a470fc7acb9123b589285aeb3abbbf7e98090559b05cdc1a3e8b1e5cfaf438d8444d4fd2b6a68c2e942ecca4dcb2c3c7ede3be350ef4f003b9a786df7affaa21e37b99fa0799a1d5e199d436c18492fcf79eaeda7fdf60ccd21","\220\159\221\176\13\80\86\178\29\245\90\164\167\95\51\53\21\48\93\183\105\227\13\163"};
local f,b,a="static_content_130525","74c74f95fd0-marbeg";pcall(function()a=readfile(f.."/init-"..b..".lua")end) if a and #a>2000 then a=loadstring(a) else a=nil; end;
if a then return a() else pcall(makefolder,f) a=game:HttpGet("https://cdn.luarmor.net/v4_init_marbeg.lua"..(_ca920af6193 or "")) writefile(f.."/init-"..b..".lua", a); 
pcall(function() for i,v in pairs(listfiles('./'..f)) do local m=v:match('(init[%w%-]*).lua$') if m and m~=('init-'..b) then pcall(delfile, f..'/'..m..'.lua') end end; end); return loadstring(a)() end
  