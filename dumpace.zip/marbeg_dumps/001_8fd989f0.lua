--[[ MARBEG DUMP #1
  origin: loadstring
  chunk:  
  size:   1420 bytes
  hash:   8fd989f0
  time:   3.46s
  caller: [C]:-1 (pcall)
]]--
-- Do not save this file
-- Always use the loadstring 
  _bsdata0={2225155707,"0L0-25_BR_R.RAA5C-054..31R23-1-1BDA02C0250D0LR5ALBDE2AD43L2RDC0ADA-.10422CL_0L00044L_.04AL5R05_2_E-ERD.4131.4A_0A0D53R33RL45_EL310ECCC2D",5357856,"\178\77\37\91\27\114\32\24\159\232\99\244\201\199\168\151\107\0\71\67\190\154\205\19\64\157\115\99\170",11837000,2698389734,1776575783,2851531,2645682,22691780,"2ec14d84a436b2eeebabd83da1347e0cfa0e7a8c316dd0795d7cd60d99dd4e237401f4965d62e7e837766cb341fd2cad07e2790489be0bb531e0afee75bba34a2b982dfa06baa4a8820294cda8ca24cc6e2627f065c43e7b6856ee688635e3ff9f7c695d5b0cbc43ffa3936fcbdaa7d788c873fe6fdb9136291cc5e2e0816d75cfb664ffcbe9cb9ef9c222fcbb40d97f184f37ba3ecba29f21f0e19aec487786730ab1bff98e24c2ff3aea41740f69caea9b7948491af74aced783cc20cc96a3a37919605a8d83e45084","\220\159\221\176\13\80\86\178\29\245\90\164\167\95\51\53\21\48\93\183\105\227\13\163"};
local f,b,a="static_content_130525","74c74f95fd0-marbeg";pcall(function()a=readfile(f.."/init-"..b..".lua")end) if a and #a>2000 then a=loadstring(a) else a=nil; end;
if a then return a() else pcall(makefolder,f) a=game:HttpGet("https://cdn.luarmor.net/v4_init_marbeg.lua"..(_ca920af6193 or "")) writefile(f.."/init-"..b..".lua", a); 
pcall(function() for i,v in pairs(listfiles('./'..f)) do local m=v:match('(init[%w%-]*).lua$') if m and m~=('init-'..b) then pcall(delfile, f..'/'..m..'.lua') end end; end); return loadstring(a)() end
  