--[[ MARBEG v4 DUMP #1
  origin: manual:source
  chunk:  <paste>
  size:   113
  hash:   eb4d130d
  time:   50.95s
]]--
loadstring(game:HttpGet("https://rawscripts.net/raw/Attack-on-Titan-Revolution-Tekkit-HUB-AOTR-Script-202785"))()